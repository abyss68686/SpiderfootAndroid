# SpiderFoot 4 für Android

Dieses Projekt verpackt die mitgelieferte **SpiderFoot-4.0.0-Quelle** als eigenständige Android-App. Der Python-Kern und CherryPy laufen innerhalb der App; die originale SpiderFoot-Weboberfläche wird in einer WebView angezeigt.

## Verhalten der App

- fester TCP-Port `1488`
- Bindung ausschließlich an `127.0.0.1` (nicht aus WLAN oder Mobilfunk erreichbar)
- zufälliger privater URL-Pfad pro Installation, damit andere Apps auf demselben Gerät nicht einfach die ungeschützte Oberfläche aufrufen können
- vollständige Einstellungen für alle eingebetteten SpiderFoot-Module einschließlich API-Schlüsseln, Moduloptionen sowie Konfigurationsimport und -export
- SQLite-Datenbank, Konfiguration, Cache und Logs bleiben im privaten App-Speicher erhalten
- Vordergrunddienst und partieller Wake-Lock halten laufende Scans beim Ausschalten des Displays aktiv
- CSV-, JSON-, XLSX-, GEXF- und Konfigurationsdownloads gehen in den Android-Downloadordner
- Links zu externen Websites werden außerhalb der WebView im normalen Browser geöffnet

## Zielgerät

Die Ausgabe ist bewusst auf `arm64-v8a` beschränkt. Sie passt damit zum Samsung Galaxy S9+ SM-G965F und zu aktuellen 64-Bit-Android-Geräten. Mindestversion ist Android 7.0 (API 24); Zielversion ist API 35.

## Android-Anpassungen

SpiderFoot startet jeden Scan normalerweise mit `multiprocessing.Process`. Android stellt die dafür erforderliche IPC-Implementierung nicht bereit. In der Android-Ausgabe werden diese Scanprozesse deshalb durch `multiprocessing.dummy.Process` ersetzt, also durch Threads mit derselben von SpiderFoot verwendeten Schnittstelle. SpiderFoot selbst verwendet innerhalb eines Scans weiterhin seine regulären Modulthreads.

Module, die ein separates Desktop-Kommando erwarten, sind nicht enthalten. Die genaue Liste steht in [ANDROID_COMPATIBILITY.md](ANDROID_COMPATIBILITY.md). Alle übrigen Module erscheinen wie gewohnt unter **New Scan** und **Settings**.

## Bauen

Benötigt werden:

- JDK 17
- Python 3.10
- Android SDK Platform 35 und Build Tools 35
- Gradle 8.11.1

Dann im Projektverzeichnis:

```bash
gradle :app:assembleDebug -PpythonCommand=python3.10
```

Die direkt installierbare, automatisch mit dem Android-Debugschlüssel signierte Datei liegt danach unter:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Alternativ enthält das Projekt einen GitHub-Actions-Workflow. **Run workflow** unter `Actions → Build Android APK` erzeugt das installierbare APK als Build-Artefakt.

## Laufzeitdaten

Die Daten liegen im privaten Verzeichnis der App unter `files/spiderfoot-data`. Android schützt diesen Bereich vor anderen normalen Apps. Beim Deinstallieren werden Datenbank, Einstellungen und API-Schlüssel gelöscht; wichtige Ergebnisse und Konfigurationen daher vorher über SpiderFoot exportieren.

## Herkunft und Lizenz

SpiderFoot stammt von Steve Micallef und steht unter der MIT-Lizenz. Die unveränderte Upstream-Lizenz ist als `app/src/main/python/sfapp/LICENSE` enthalten. Die Android-Integrationsdateien dieses Projekts stehen ebenfalls unter MIT.
