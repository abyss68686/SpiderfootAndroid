plugins {
    id("com.android.application") version "8.9.3" apply false
    id("com.chaquo.python") version "17.0.0" apply false
}
